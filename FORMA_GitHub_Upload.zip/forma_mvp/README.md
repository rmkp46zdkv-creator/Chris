# FORMA — AI Interior Design Studio

A small Node.js + Express MVP for FORMA's conversational interior-design assistant.

## Features
- Chat with FORMA AI
- Optional JPG, PNG or WEBP room-photo upload
- Six design directions: Modern, Minimal, Luxury, Japandi, Mediterranean and Contemporary
- Optional AI image generation
- Multi-turn chat context during the current browser session
- Health endpoint at `/api/health`

## Deploy on Render
1. Push the contents of this folder to a GitHub repository.
2. In Render, create a **Web Service** and connect that repository.
3. Use these settings:
   - Runtime: `Node`
   - Build command: `npm install`
   - Start command: `npm start`
4. In Render → Environment, add `OPENAI_API_KEY` with your own API key.
5. Optional environment variables:
   - `OPENAI_CHAT_MODEL=gpt-5.5`
   - `OPENAI_IMAGE_MODEL=gpt-image-2.5-flare`
6. Deploy. Render provides the public website URL when the deploy succeeds.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env` and add your OpenAI API key.
4. Run `npm start` and open `http://localhost:3000`.

## Security and limitations
- Never commit `.env` or paste your API key into browser code, GitHub, or a chat message.
- Set the API key only in Render's private Environment settings for deployment.
- API use, especially image generation, may incur charges.
- This is an MVP, not a production-ready public service. Before launch, add user authentication, rate limiting, private image storage, usage limits, privacy controls and monitoring.
- Generated images are concept visuals, not measured or construction-ready drawings.
