import "dotenv/config";
import express from "express";
import multer from "multer";
import OpenAI, { toFile } from "openai";
import path from "node:path";
import fs from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 12 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    cb(allowed.includes(file.mimetype) ? null : new Error("Please upload a JPG, PNG, or WEBP image."), allowed.includes(file.mimetype));
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.use("/generated", express.static(path.join(__dirname, "generated")));

const styleDirections = {
  Modern: "warm modern architecture, clean lines, sculptural furniture, balanced natural materials",
  Minimal: "quiet minimalism, restrained furniture, uncluttered surfaces, soft neutral palette",
  Luxury: "understated contemporary luxury, premium stone, rich tactile fabrics, bespoke details",
  Japandi: "Japandi design, natural oak, soft forms, calm functionality, handmade textures",
  Mediterranean: "modern Mediterranean character, limewash, natural stone, warm earthy tones",
  Contemporary: "contemporary interior architecture, confident forms, curated art, refined materials"
};

app.post("/api/chat", upload.single("room"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "FORMA AI is not connected yet. Add OPENAI_API_KEY to .env and restart the app." });
    }

    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ error: "Write a message to FORMA AI first." });

    const wantsImage = req.body.generateImage === "true";
    const previousResponseId = String(req.body.previousResponseId || "").trim();
    const style = String(req.body.style || "Modern");
    const direction = styleDirections[style] || styleDirections.Modern;

    const content = [{ type: "input_text", text:
      `You are FORMA AI, a thoughtful professional interior designer based in Milan.
Help users develop practical, beautiful interior concepts. Be concise, ask useful follow-up questions when needed,
and explain design choices in terms of layout, light, materials, color, furniture and atmosphere.
Current selected style: ${style} (${direction}).
If the user asks for technical or construction advice, clearly distinguish conceptual guidance from verified measurements or professional documentation.
${wantsImage ? "The user explicitly requested an image now. Use the image generation tool to create or edit a photorealistic interior concept that follows the conversation and any uploaded room photo." : "Do not generate an image unless the user explicitly requests one. Continue the conversation with text only."}
User message: ${message}`
    }];

    if (req.file) {
      const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
      content.push({ type: "input_image", image_url: dataUrl, detail: "high" });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const params = {
      model: process.env.OPENAI_CHAT_MODEL || "gpt-5.5",
      input: [{ role: "user", content }],
      store: true
    };
    if (previousResponseId) params.previous_response_id = previousResponseId;
    if (wantsImage) {
      params.tools = [{
        type: "image_generation",
        model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare",
        action: "auto",
        partial_images: 2
      }];
      params.tool_choice = { type: "image_generation" };
    }

    const response = await client.responses.create(params);
    const outputText = response.output_text || "I've considered your request. What would you like to refine next?";
    let imageUrl = null;

    for (const item of (response.output || [])) {
      if (item.type === "image_generation_call" && item.result) {
        const filename = `${randomUUID()}.png`;
        await fs.writeFile(path.join(__dirname, "generated", filename), Buffer.from(item.result, "base64"));
        imageUrl = `/generated/${filename}`;
      }
    }

    res.json({ text: outputText, imageUrl, responseId: response.id });
  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message || "FORMA AI could not complete that request." });
  }
});

app.post("/api/design", upload.single("room"), async (req, res) => {
  req.body.generateImage = "true";
  req.body.message = `Create a photorealistic redesign of my uploaded room in ${req.body.style || "Modern"} style. ${String(req.body.notes || "")}`;
  // Keep the original one-shot endpoint as a compatibility alias for older prototype clients.
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "The AI engine is not connected yet. Add OPENAI_API_KEY to .env and restart FORMA." });
    }
    if (!req.file) return res.status(400).json({ error: "Upload a room photo first." });
    const style = String(req.body.style || "Modern");
    const direction = styleDirections[style] || styleDirections.Modern;
    const prompt = `Redesign the uploaded room photograph as a photorealistic interior architecture concept. Preserve the original room's recognizable geometry, camera angle, doors and windows. Design direction: ${direction}. Use realistic furniture scale, refined materials and natural light. ${String(req.body.notes || "")}`;
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const imageFile = await toFile(req.file.buffer, req.file.originalname || "room-photo.png", { type: req.file.mimetype });
    const result = await client.images.edit({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-sunburst",
      image: imageFile, prompt, quality: "high", size: "1536x1024", output_format: "png"
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error("The image service returned no image. Please try again.");
    const filename = `${randomUUID()}.png`;
    await fs.writeFile(path.join(__dirname, "generated", filename), Buffer.from(b64, "base64"));
    res.json({ imageUrl: `/generated/${filename}`, style });
  } catch (err) {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message || "Something went wrong while creating your design." });
  }
});

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    aiConnected: Boolean(process.env.OPENAI_API_KEY),
    chatModel: process.env.OPENAI_CHAT_MODEL || "gpt-5.5",
    imageModel: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare"
  });
});

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || "Upload error." });
});

app.listen(PORT, () => console.log(`FORMA is running at http://localhost:${PORT}`));
